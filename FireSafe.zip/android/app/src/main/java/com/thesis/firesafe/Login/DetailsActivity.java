package com.thesis.firesafe.Login;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import com.addisonelliott.segmentedbutton.SegmentedButtonGroup;
import com.google.android.gms.tasks.OnCompleteListener;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.thesis.firesafe.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


/**
 * Fragment Responsible for registering a new user
 */
public class DetailsActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mName,number;

    private SegmentedButtonGroup mRadioGroup;

    private  String verificationCode;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        initializeObjects();
    }


    /**
     * Register the user, but before that check if every field is correct.
     * After that registers the user and creates an entry for it oin the database
     */
    private void register() {
        if (mName.getText().length() == 0) {
            mName.setError("please fill this field");
            return;
        }

        if(number.getText().length()==0) {
            number.setError("please fill this field");
            return;
        }

        final String name = mName.getText().toString();
        final String accountType;
        int selectId = mRadioGroup.getPosition();

        if (selectId == 1) {
            accountType = "Drivers";
        } else {
            accountType = "Customers";
        }

        AlertDialog.Builder alert = new AlertDialog.Builder(DetailsActivity.this);
        alert.setTitle("Data Privacy");
        alert.setMessage("TERMS OF SERVICE\n" +
                "\n" +
                "OVERVIEW\n" +
                "\n" +
                "This application is operated by the Fire Safe developers. Throughout the application, the terms “we”, “us” and “our” refer to the Fire SAFE Application Developers. The developers of this Application offers this application, including all information, tools and services available from this app to you, the user, conditioned upon your acceptance of all terms, conditions, policies and notices stated here.\n" +
                "\n" +
                "By using our application, you engage in our “Service” and agree to be bound by the following terms and conditions (“Terms of Service”, “Terms”), including those additional terms and conditions and policies referenced herein and/or available by hyperlink. These Terms of Service apply  to all users of the application.\n" +
                "\n" +
                "Please read these Terms of Service carefully before accessing or using our application. By accessing or using any part of the app, you agree to be bound by these Terms of Service. If you do not agree to all the terms and conditions of this agreement, then you may not access the app or use any services.\n" +
                "\n" +
                "You may not use our products for any illegal or unauthorized purpose nor may you, in the use of the Service, violate any laws in your jurisdiction (including but not limited to copyright laws).\n" +
                "\n" +
                "You must not transmit any worms or viruses or any code of a destructive nature.\n" +
                "\n" +
                "A breach or violation of any of the Terms will result in an immediate termination of your Services.\n" +
                "\n" +
                "ACCURACY, COMPLETENESS AND TIMELINESS OF INFORMATION\n" +
                "\n" +
                "We are not responsible if information made available on this app is not accurate, complete or current. The material on this app is provided for general information only and should not be relied upon or used as the sole basis for making decisions without consulting primary, more accurate, more complete or more timely sources of information. Any reliance on the material on this site is at your own risk.\n" +
                "\n" +
                "GOVERNING LAW\n" +
                "\n" +
                "These Terms of Service and any separate agreements whereby we provide you Services shall be governed by and construed in accordance with the laws of Philippines.");

        alert.setPositiveButton("Yes, I agree", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                new HTTPReqTask().execute();
                AlertDialog.Builder builder = new AlertDialog.Builder(DetailsActivity.this);
                builder.setTitle("OTP Verification");

                // Set up the input
                final EditText input = new EditText(DetailsActivity.this);
                // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("Verify", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String m_Text = input.getText().toString();
                        if (m_Text != verificationCode){
                            String user_id = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            Map<String, Object> newUserMap = new HashMap<>();
                            newUserMap.put("name", name);
                            newUserMap.put("profileImageUrl", "default");
                            if (accountType.equals("Drivers")) {
                                newUserMap.put("service", "type_1");
                                newUserMap.put("activated", true);
                            }
                            FirebaseDatabase.getInstance().getReference().child("Users").child(accountType).child(user_id).updateChildren(newUserMap).addOnCompleteListener((OnCompleteListener<Void>) task -> {
                                Intent intent = new Intent(DetailsActivity.this, LauncherActivity.class);
                                startActivity(intent);
                                finish();
                            });
                        }else{
                            Toast.makeText(DetailsActivity.this, "Wrong OTP Code", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        alert.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        Intent myIntent = new Intent(DetailsActivity.this, AuthenticationActivity.class);
                        startActivity(myIntent);
                    }
                });

        alert.show();
    }


    /**
     * Initializes the design Elements and calls clickListeners for them
     */
    private void initializeObjects() {
        mName = findViewById(R.id.name);
        Button mRegister = findViewById(R.id.register);
        mRadioGroup = findViewById(R.id.radioRealButtonGroup);
        number = findViewById(R.id.number);

        mRadioGroup.setPosition(0, false);
        mRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.register) {
            register();
        }
    }

    public class HTTPReqTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            HttpURLConnection urlConnection = null;
            verificationCode = new DecimalFormat("000000").format(new Random().nextInt(999999));

            try {
                URL url = new URL("http://122.54.191.90:8085/goip_send_sms.html?username=root&password=root&port=2&recipients="+number.getText().toString()+"&sms="+ URLEncoder.encode("Hello "+mName.getText().toString()+" This is your OTP code for Registration:"+verificationCode));
                urlConnection = (HttpURLConnection) url.openConnection();

                int code = urlConnection.getResponseCode();
                if (code !=  200) {
                    throw new IOException("Invalid response from server: " + code);
                }

                BufferedReader rd = new BufferedReader(new InputStreamReader(
                        urlConnection.getInputStream()));
                String line;
                while ((line = rd.readLine()) != null) {
                    Log.i("data", line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            return null;
        }
    }


}